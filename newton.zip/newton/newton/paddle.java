import greenfoot.*;  

public class paddle extends Actor

{
    public void act()
    {
        checkKeys();
    } 
    
    private int speed = 7;
    
    private void checkKeys() 
    {
        if (Greenfoot.isKeyDown("left")) 
        {
            moveLeft();
        }
        if (Greenfoot.isKeyDown("right"))
        {
            moveRight();
        }
    }
     
    public void moveRight()
    {
        setLocation ( getX() + speed, getY() );
    }
    
    public void moveLeft()
    {
        setLocation ( getX() - speed, getY() );
    }
    
      public void lookForBody()
    {
        if ( isTouching(Body.class) ) 
        {
            removeTouching(Body.class);
            Greenfoot.playSound("au.wav");
            Greenfoot.stop();
        }
    }
}
