import greenfoot.*;  
import java.awt.Color;
import java.util.List;

public class Body extends SmoothMover
{
    private static final double GRAVITY = 7.8;
    private static final Color defaultColor = new Color(255, 216, 0);
    
    private double mass;
    
    public Body()
    {
        this (20, 300, new Vector(0, 0.0), defaultColor);
    }
    
    public Body(int size, double mass, Vector velocity, Color color)
    {
        this.mass = mass;
        addToVelocity(velocity);
        GreenfootImage image = new GreenfootImage (size, size);
        image.setColor (color);
        image.fillOval (0, 0, size-1, size-1);
        setImage (image);
    }
    
    public void act() 
    {
        applyForces();
        move();
        bounceAtEdge();
        lookForPaddle();
    }
    
    private void bounceAtEdge()
    {
        if (getX() == 0 || getX() == getWorld().getWidth()-1) {
            setLocation((double)getX(), (double)getY());
            invertHorizontalVelocity();
            accelerate(0.9);
        }
        else if (getY() == 0 || getY() == getWorld().getHeight()-1) {
            setLocation((double)getX(), (double)getY());
            invertVerticalVelocity();
            accelerate(0.9);
        }
    }
    
    private void applyForces()
    {
        List<Body> bodies = getWorld().getObjects(Body.class);
        
        for (Body body : bodies) 
        {
            if (body != this) 
            {
                applyGravity(body);
            }
        }
        
        if (getSpeed() > 7) 
        {
            accelerate (0.9); 
        }
    }
    
    private void applyGravity(Body other)
    {
        double dx = other.getExactX() - this.getExactX();
        double dy = other.getExactY() - this.getExactY();
        Vector dv = new Vector (dx, dy);
        double distance = Math.sqrt (dx*dx + dy*dy);
        double force = GRAVITY * this.mass * other.mass / (distance * distance);
        double acceleration = force / this.mass;
        dv.setLength (acceleration);
        addToVelocity (dv);
    }
    
    public double getMass()
    {
        return mass;
    }
    
      public void lookForPaddle()
    {
        if ( isTouching(paddle.class) ) 
        {
            removeTouching(paddle.class);
            Greenfoot.playSound("au.wav");
            Greenfoot.stop();
        }
    }
}

