import greenfoot.*;


public class MyWorld extends World
{
   
    public MyWorld()
    {    
        super(600, 400, 1);
        setUp();
    }
    
 
    private void setUp()
    {
        int i = 0;
        while (i<18) {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject( new Leaf(), x, y );
            i++;
        }
        
        addObject(new Block(), 300, 200);
    }
}
