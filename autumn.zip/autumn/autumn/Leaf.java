import greenfoot.*;

public class Leaf extends Actor
{
    private int speed;
    GreenfootImage img1 = new GreenfootImage("leaf-green.png");
    GreenfootImage img2 = new GreenfootImage("leaf-brown.png");
    
    public Leaf()
    {
        setImage(img1);
        speed = Greenfoot.getRandomNumber(3) + 1;      
        setRotation(Greenfoot.getRandomNumber(360));
    }
    
    public void act() 
    {
        if (isAtEdge()) 
        {
            turn(180);
        }
        
        move(speed);
        
        if (Greenfoot.getRandomNumber(100) < 50) 
        {
            turn(Greenfoot.getRandomNumber(5) - 2);   
        }
    }
   
    public void changeImage()
    {
        if (getImage() == img1) 
        {
            setImage(img2);
        }
        else {
            setImage(img1);
        }
    }
}
