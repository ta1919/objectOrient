import greenfoot.*;  
import java.util.List;


public class Block extends Actor
{
    private int delta = 2;
    
    public void act() 
    {
        move();
        checkEdge();
        checkLeaf();
        checkMouseClick();
    }
    
    private void move()
    {
        setLocation(getX()+delta, getY());
    }
    
    private void checkEdge()
    {
        if (isAtEdge()) 
        {
            delta = -delta;
        }
    }
    
    private void checkMouseClick()
    {
        if (Greenfoot.mouseClicked(null)) 
        {
            World world = getWorld();
            List<Leaf> leaves = world.getObjects(Leaf.class);

            for (Leaf leaf : leaves)
            {
                leaf.changeImage();
            }
        }
    }
    
    private void checkLeaf()
    {
        Leaf leaf = (Leaf) getOneIntersectingObject(Leaf.class);
        
        if (leaf != null) {
            leaf.turn(9);
        }
    }
}
