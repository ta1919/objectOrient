import greenfoot.*;  
public class Virus extends Actor
{
    /**
     * Float along, slowly rotating.
     */
    public void act() 
    {
        setLocation(getX()-8, getY());
        turn(-1);
        
        if (getX() == 0) 
        {
            getWorld().removeObject(this);
        }
    }    
}
